/**
 * Metro configuration for React Native
 */
const { getDefaultConfig, mergeConfig } = require('@react-native/metro-config');

const defaultConfig = getDefaultConfig(__dirname);

const config = {
  resolver: {
    // Support for shared code between mobile and desktop
    sourceExts: ['js', 'jsx', 'json', 'ts', 'tsx', 'cjs', 'mjs'],
    assetExts: ['glb', 'gltf', 'png', 'jpg', 'ttf', 'obj', 'mtl'],
  },
  watchFolders: [
    // Watch shared source code
    __dirname + '/src',
    __dirname + '/shared',
  ],
};

module.exports = mergeConfig(defaultConfig, config);
