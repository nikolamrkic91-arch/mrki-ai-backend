# Mrki Swarm - AI Swarm Orchestration Platform

A full-stack SaaS platform that orchestrates AI agents using the Swarm pattern with React 19, Tailwind CSS, FastAPI, and Node.js.

## 🎯 The 8 Points Implemented

### 1. Code Generation ✅
- **React/Tailwind Code Generator**: Converts natural language prompts into production-ready React components
- **Multi-framework support**: React, Vue, Angular
- **TypeScript-first**: Full type safety
- **Live preview**: See generated code in real-time

### 2. Full-Stack Architecture ✅
- **Frontend**: React 19 + TypeScript + Tailwind CSS + Vite
- **Backend**: FastAPI (Python) + Node.js hybrid
- **UI Components**: Shadcn/UI + Lucide React icons
- **Real-time**: WebSocket communication

### 3. Visual Prototyping ✅
- **Dark-mode dashboard**: Modern, responsive UI
- **Swarm Activity feed**: Live reasoning logs from agents
- **Control Center**: Toggle agents and dispatch tasks
- **Agent Status Cards**: Real-time agent monitoring

### 4. Intelligence (ReAct Pattern) ✅
- **ReAct Reasoning Loop**: Transparent AI reasoning
  - **THOUGHT**: Internal reasoning about the task
  - **ACTION**: What the agent decides to do
  - **OBSERVATION**: What the agent observes
- **Visual reasoning chain**: See the AI's thought process
- **Step-by-step execution**: Track each reasoning step

### 5. Multi-Agent Swarm ✅
- **Swarm Manager**: Orchestrates 3 specialized agents
  - **Agent A (Researcher)**: Fetches and parses real-time data
  - **Agent B (Analyst)**: Processes data and performs sentiment analysis
  - **Agent C (Writer)**: Generates formatted executive summary
- **Shared Memory**: Context passing between agents
- **Parallel execution**: Run agents simultaneously

### 6. Environment (Docker) ✅
- **Docker Compose**: Complete local development stack
- **Services**:
  - Frontend (React + Vite)
  - Backend (FastAPI)
  - Redis (Caching)
  - Ollama (Local LLMs)
  - Nginx (Reverse proxy)
- **One-command setup**: `docker-compose up -d`

### 7. Deployment (CI/CD) ✅
- **GitHub Actions**: Automated deployment pipeline
- **Frontend**: Deploy to Vercel
- **Backend**: Deploy to AWS Lambda/Fargate
- **Infrastructure**: Terraform for AWS resources
- **Container Registry**: Amazon ECR

### 8. Local Processing (Ollama) ✅
- **Ollama Integration**: Local LLM processing
- **Privacy-focused**: Data-sensitive tasks stay local
- **Models**: Llama 3.2, CodeLlama, Mistral
- **Fallback**: Switch between cloud and local LLMs

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 20+
- Python 3.11+

### Local Development

```bash
# Clone the repository
git clone https://github.com/yourusername/mrki.git
cd mrki/swarm

# Start all services
docker-compose up -d

# Access the application
open http://localhost:3000

# API documentation
open http://localhost:8000/docs
```

### Manual Setup

```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload

# Frontend (new terminal)
cd frontend
npm install
npm run dev
```

## 📁 Project Structure

```
swarm/
├── frontend/                 # React 19 + Tailwind + Vite
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── hooks/           # Custom hooks (useSwarm, useReAct, useWebSocket)
│   │   ├── types/           # TypeScript types
│   │   └── utils/           # Utility functions
│   ├── package.json
│   └── Dockerfile
│
├── backend/                  # FastAPI + Python
│   ├── swarm/               # Swarm modules
│   │   ├── orchestrator.py  # Agent orchestration
│   │   ├── agents.py        # 3 specialized agents
│   │   ├── memory.py        # Shared memory
│   │   ├── react.py         # ReAct engine
│   │   ├── code_generator.py
│   │   └── ollama_integration.py
│   ├── main.py              # FastAPI entry point
│   ├── requirements.txt
│   └── Dockerfile
│
├── nginx/                    # Reverse proxy config
├── .github/workflows/        # CI/CD pipelines
├── docker-compose.yml        # Local development stack
└── README.md
```

## 🎨 Features

### Swarm Activity Feed
- Real-time agent activity logs
- Thought/Action/Observation steps
- Code generation events
- Error tracking

### Control Center
- Agent toggle switches
- Quick actions (Generate Code, Analyze, Terminal)
- System status monitoring
- Connection status

### Code Generator
- Natural language to code
- React/Vue/Angular support
- TypeScript generation
- Download/copy generated code

### ReAct Reasoning Panel
- Visual reasoning chain
- Step-by-step breakdown
- Agent attribution
- Timestamp tracking

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the root:

```env
# API Keys
OPENAI_API_KEY=your_openai_key
ANTHROPIC_API_KEY=your_anthropic_key

# Ollama
OLLAMA_HOST=http://localhost:11434

# Redis
REDIS_URL=redis://localhost:6379

# AWS (for deployment)
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
AWS_REGION=us-east-1

# Vercel
VERCEL_TOKEN=your_token
```

## 🌐 API Endpoints

### Swarm Operations
- `POST /swarm/run` - Execute swarm task
- `GET /swarm/status` - Get swarm status
- `WebSocket /ws` - Real-time updates

### Code Generation
- `POST /code/generate` - Generate code from prompt

### Health
- `GET /health` - Health check

## 🚢 Deployment

### Deploy to Vercel + AWS

```bash
# Push to main branch
git push origin main

# GitHub Actions will automatically:
# 1. Test the code
# 2. Deploy frontend to Vercel
# 3. Deploy backend to AWS Lambda/Fargate
# 4. Update infrastructure with Terraform
```

### Manual Deployment

```bash
# Frontend to Vercel
cd frontend
vercel --prod

# Backend to AWS
cd backend
serverless deploy
```

## 🧪 Testing

```bash
# Backend tests
cd backend
pytest tests/ -v

# Frontend tests
cd frontend
npm test
```

## 📚 Documentation

- [API Documentation](http://localhost:8000/docs) - Interactive Swagger UI
- [Architecture](./docs/ARCHITECTURE.md) - System design
- [Deployment](./docs/DEPLOYMENT.md) - Deployment guide

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📄 License

MIT License - See [LICENSE](../LICENSE) for details

## 🙏 Acknowledgments

- React 19 Team
- Tailwind CSS
- FastAPI
- Ollama
- Shadcn/UI
