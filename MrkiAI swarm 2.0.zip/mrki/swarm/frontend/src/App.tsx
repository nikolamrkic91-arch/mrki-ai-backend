import React, { useState, useEffect } from 'react';
import { 
  Sidebar, 
  ActivityFeed, 
  ControlCenter, 
  AgentCard,
  ReasoningPanel,
  CodeGenerator,
  SwarmManager
} from './components';
import { useSwarm, useReAct, useWebSocket } from './hooks';
import { Agent, Task, ReasoningStep } from './types';
import './styles/globals.css';

// Mrki - AI Swarm Orchestration Platform
// React 19 + Tailwind CSS + Shadcn/UI

function App() {
  const [darkMode, setDarkMode] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'agents' | 'code' | 'settings'>('dashboard');
  
  const { 
    agents, 
    tasks, 
    swarmActivity, 
    dispatchTask, 
    toggleAgent,
    getAgentStatus 
  } = useSwarm();
  
  const { 
    reasoningChain, 
    currentStep, 
    isReasoning 
  } = useReAct();
  
  const { 
    isConnected, 
    lastMessage 
  } = useWebSocket('ws://localhost:8080/ws');

  return (
    <div className={`min-h-screen ${darkMode ? 'dark' : ''}`}>
      <div className="flex h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
        {/* Sidebar Navigation */}
        <Sidebar 
          activeTab={activeTab}
          onTabChange={setActiveTab}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode(!darkMode)}
          isConnected={isConnected}
        />

        {/* Main Content Area */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="h-16 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-6">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                Mrki Swarm
              </h1>
              <span className="px-3 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 text-xs font-medium rounded-full">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
            <div className="flex items-center gap-4">
              <button 
                onClick={() => dispatchTask({ type: 'SWARM_ORCHESTRATE', payload: {} })}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
              >
                Run Swarm
              </button>
            </div>
          </header>

          {/* Dashboard Content */}
          <div className="flex-1 overflow-auto p-6">
            {activeTab === 'dashboard' && (
              <div className="grid grid-cols-12 gap-6">
                {/* Swarm Activity Feed */}
                <div className="col-span-8 space-y-6">
                  <ActivityFeed 
                    activities={swarmActivity}
                    className="h-[500px]"
                  />
                  
                  {/* ReAct Reasoning Panel */}
                  <ReasoningPanel 
                    steps={reasoningChain}
                    currentStep={currentStep}
                    isReasoning={isReasoning}
                  />
                </div>

                {/* Control Center */}
                <div className="col-span-4 space-y-6">
                  <ControlCenter 
                    agents={agents}
                    onToggleAgent={toggleAgent}
                    onDispatchTask={dispatchTask}
                  />
                  
                  {/* Agent Status Cards */}
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Active Agents
                    </h3>
                    {agents.map((agent) => (
                      <AgentCard 
                        key={agent.id}
                        agent={agent}
                        status={getAgentStatus(agent.id)}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'agents' && (
              <SwarmManager />
            )}

            {activeTab === 'code' && (
              <CodeGenerator />
            )}

            {activeTab === 'settings' && (
              <SettingsPanel />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
