import React, { useRef, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { 
  Bot, 
  Code, 
  Brain, 
  CheckCircle, 
  AlertCircle, 
  MessageSquare 
} from 'lucide-react';
import { Activity } from '../types';

interface ActivityFeedProps {
  activities: Activity[];
  className?: string;
}

export const ActivityFeed: React.FC<ActivityFeedProps> = ({ 
  activities, 
  className = '' 
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activities]);

  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'THOUGHT':
        return <Brain className="w-4 h-4 text-purple-500" />;
      case 'ACTION':
        return <Bot className="w-4 h-4 text-blue-500" />;
      case 'OBSERVATION':
        return <MessageSquare className="w-4 h-4 text-green-500" />;
      case 'CODE_GENERATION':
        return <Code className="w-4 h-4 text-yellow-500" />;
      case 'COMPLETED':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'ERROR':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Bot className="w-4 h-4 text-gray-500" />;
    }
  };

  const getActivityColor = (type: Activity['type']) => {
    switch (type) {
      case 'THOUGHT':
        return 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800';
      case 'ACTION':
        return 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800';
      case 'OBSERVATION':
        return 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800';
      case 'CODE_GENERATION':
        return 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800';
      case 'COMPLETED':
        return 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800';
      case 'ERROR':
        return 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800';
      default:
        return 'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700';
    }
  };

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 ${className}`}>
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <Bot className="w-5 h-5" />
          Swarm Activity
        </h2>
      </div>
      
      <div 
        ref={scrollRef}
        className="p-4 space-y-3 overflow-y-auto h-[calc(100%-60px)]"
      >
        {activities.length === 0 ? (
          <div className="text-center text-gray-500 dark:text-gray-400 py-8">
            No activity yet. Start a swarm task to see live reasoning.
          </div>
        ) : (
          activities.map((activity, index) => (
            <div 
              key={index}
              className={`p-3 rounded-lg border ${getActivityColor(activity.type)} transition-all animate-fadeIn`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  {getActivityIcon(activity.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                      {activity.agentName}
                    </span>
                    <span className="text-xs text-gray-400 dark:text-gray-500">
                      {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-gray-900 dark:text-gray-100 whitespace-pre-wrap">
                    {activity.message}
                  </p>
                  {activity.metadata && (
                    <div className="mt-2 text-xs text-gray-500 dark:text-gray-400 font-mono bg-gray-100 dark:bg-gray-900 p-2 rounded">
                      {JSON.stringify(activity.metadata, null, 2)}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
