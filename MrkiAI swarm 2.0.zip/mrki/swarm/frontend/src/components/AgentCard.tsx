import React from 'react';
import { Bot, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { Agent } from '../types';

interface AgentCardProps {
  agent: Agent;
  status: 'idle' | 'working' | 'completed' | 'error';
}

export const AgentCard: React.FC<AgentCardProps> = ({ agent, status }) => {
  const getStatusIcon = () => {
    switch (status) {
      case 'working':
        return <Loader2 className="w-4 h-4 animate-spin text-blue-500" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Bot className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'working':
        return 'border-blue-500 bg-blue-50 dark:bg-blue-900/20';
      case 'completed':
        return 'border-green-500 bg-green-50 dark:bg-green-900/20';
      case 'error':
        return 'border-red-500 bg-red-50 dark:bg-red-900/20';
      default:
        return 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800';
    }
  };

  return (
    <div className={`p-3 rounded-lg border ${getStatusColor()} transition-all`}>
      <div className="flex items-center gap-3">
        <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
          <agent.icon className="w-4 h-4 text-gray-600 dark:text-gray-400" />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium text-gray-900 dark:text-white truncate">
              {agent.name}
            </h4>
            {getStatusIcon()}
          </div>
          
          <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
            {agent.description}
          </p>
        </div>
      </div>
      
      {status === 'working' && (
        <div className="mt-2">
          <div className="h-1 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 animate-pulse rounded-full" style={{ width: '60%' }} />
          </div>
        </div>
      )}
    </div>
  );
};
