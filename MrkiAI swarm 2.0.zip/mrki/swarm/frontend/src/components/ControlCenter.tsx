import React from 'react';
import { 
  Power, 
  PowerOff, 
  Settings, 
  Activity,
  Terminal,
  Code,
  Layout
} from 'lucide-react';
import { Agent } from '../types';

interface ControlCenterProps {
  agents: Agent[];
  onToggleAgent: (agentId: string) => void;
  onDispatchTask: (task: any) => void;
}

export const ControlCenter: React.FC<ControlCenterProps> = ({ 
  agents, 
  onToggleAgent, 
  onDispatchTask 
}) => {
  const activeAgents = agents.filter(a => a.status === 'working').length;
  const totalAgents = agents.length;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Control Center
        </h2>
      </div>

      <div className="p-4 space-y-4">
        {/* Status Overview */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
              {activeAgents}
            </div>
            <div className="text-xs text-blue-600 dark:text-blue-400">
              Active Agents
            </div>
          </div>
          <div className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
            <div className="text-2xl font-bold text-gray-600 dark:text-gray-400">
              {totalAgents}
            </div>
            <div className="text-xs text-gray-600 dark:text-gray-400">
              Total Agents
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Quick Actions
          </h3>
          
          <button
            onClick={() => onDispatchTask({ type: 'GENERATE_CODE', payload: {} })}
            className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
          >
            <Code className="w-4 h-4" />
            Generate Code
          </button>
          
          <button
            onClick={() => onDispatchTask({ type: 'ANALYZE_PROJECT', payload: {} })}
            className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
          >
            <Activity className="w-4 h-4" />
            Analyze Project
          </button>
          
          <button
            onClick={() => onDispatchTask({ type: 'OPEN_TERMINAL', payload: {} })}
            className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
          >
            <Terminal className="w-4 h-4" />
            Open Terminal
          </button>
        </div>

        {/* Agent Toggles */}
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Agent Control
          </h3>
          
          {agents.map((agent) => (
            <div 
              key={agent.id}
              className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700/50 rounded-lg"
            >
              <div className="flex items-center gap-2">
                <agent.icon className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {agent.name}
                </span>
              </div>
              
              <button
                onClick={() => onToggleAgent(agent.id)}
                className={`p-1.5 rounded transition-colors ${
                  agent.status !== 'idle'
                    ? 'text-green-600 hover:bg-green-100 dark:hover:bg-green-900/30'
                    : 'text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {agent.status !== 'idle' ? (
                  <Power className="w-4 h-4" />
                ) : (
                  <PowerOff className="w-4 h-4" />
                )}
              </button>
            </div>
          ))}
        </div>

        {/* System Status */}
        <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500 dark:text-gray-400">System Status</span>
            <span className="text-green-600 dark:text-green-400 font-medium flex items-center gap-1">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              Operational
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
