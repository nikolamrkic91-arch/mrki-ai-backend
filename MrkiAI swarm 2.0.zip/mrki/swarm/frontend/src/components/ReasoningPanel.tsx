import React from 'react';
import { Brain, Play, Eye, MessageSquare, Loader2 } from 'lucide-react';
import { ReasoningStep } from '../types';

interface ReasoningPanelProps {
  steps: ReasoningStep[];
  currentStep: number;
  isReasoning: boolean;
}

export const ReasoningPanel: React.FC<ReasoningPanelProps> = ({ 
  steps, 
  currentStep, 
  isReasoning 
}) => {
  const getStepIcon = (type: ReasoningStep['type']) => {
    switch (type) {
      case 'THOUGHT':
        return <Brain className="w-4 h-4" />;
      case 'ACTION':
        return <Play className="w-4 h-4" />;
      case 'OBSERVATION':
        return <Eye className="w-4 h-4" />;
      default:
        return <MessageSquare className="w-4 h-4" />;
    }
  };

  const getStepColor = (type: ReasoningStep['type'], isActive: boolean) => {
    if (!isActive) return 'text-gray-400 dark:text-gray-600';
    
    switch (type) {
      case 'THOUGHT':
        return 'text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-900/30';
      case 'ACTION':
        return 'text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/30';
      case 'OBSERVATION':
        return 'text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/30';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
            <Brain className="w-5 h-5" />
            ReAct Reasoning Loop
          </h2>
          {isReasoning && (
            <div className="flex items-center gap-2 text-sm text-blue-600 dark:text-blue-400">
              <Loader2 className="w-4 h-4 animate-spin" />
              Reasoning...
            </div>
          )}
        </div>
      </div>

      <div className="p-4">
        {steps.length === 0 ? (
          <div className="text-center text-gray-500 dark:text-gray-400 py-8">
            No reasoning steps yet. The swarm will show its thought process here.
          </div>
        ) : (
          <div className="space-y-4">
            {steps.map((step, index) => {
              const isActive = index === currentStep;
              const isPast = index < currentStep;
              
              return (
                <div 
                  key={index}
                  className={`relative flex gap-4 ${isActive ? 'opacity-100' : isPast ? 'opacity-60' : 'opacity-40'}`}
                >
                  {/* Timeline line */}
                  {index < steps.length - 1 && (
                    <div className="absolute left-5 top-8 bottom-0 w-0.5 bg-gray-200 dark:bg-gray-700" />
                  )}
                  
                  {/* Step indicator */}
                  <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${getStepColor(step.type, isActive || isPast)}`}>
                    {getStepIcon(step.type)}
                  </div>
                  
                  {/* Step content */}
                  <div className="flex-1 pb-4">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium uppercase tracking-wide text-gray-500 dark:text-gray-400">
                        {step.type}
                      </span>
                      {step.agentName && (
                        <span className="text-xs text-gray-400 dark:text-gray-500">
                          • {step.agentName}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-900 dark:text-gray-100">
                      {step.content}
                    </p>
                    {step.action && (
                      <div className="mt-2 p-2 bg-gray-100 dark:bg-gray-900 rounded text-xs font-mono text-gray-700 dark:text-gray-300">
                        Action: {step.action}
                      </div>
                    )}
                    {step.observation && (
                      <div className="mt-2 p-2 bg-green-50 dark:bg-green-900/20 rounded text-xs text-green-800 dark:text-green-200">
                        Observation: {step.observation}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
