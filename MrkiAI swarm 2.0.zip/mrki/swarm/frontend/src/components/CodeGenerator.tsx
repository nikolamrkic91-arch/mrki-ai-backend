import React, { useState } from 'react';
import { 
  Code, 
  Copy, 
  Check, 
  Play, 
  Download,
  FileCode,
  Layout,
  Palette
} from 'lucide-react';
import { generateReactComponent, generateTailwindConfig } from '../utils/codeGenerator';

interface GeneratedFile {
  name: string;
  language: string;
  content: string;
}

export const CodeGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedFiles, setGeneratedFiles] = useState<GeneratedFile[]>([]);
  const [activeFile, setActiveFile] = useState(0);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const generateCode = async () => {
    if (!prompt.trim() || isGenerating) return;
    
    setIsGenerating(true);
    
    // Simulate code generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const files: GeneratedFile[] = [
      {
        name: 'Component.tsx',
        language: 'typescript',
        content: generateReactComponent(prompt)
      },
      {
        name: 'styles.css',
        language: 'css',
        content: `/* Tailwind CSS classes used */\n/* ${prompt} */\n\n.component {\n  @apply bg-white dark:bg-gray-800 rounded-lg shadow-md;\n}`
      },
      {
        name: 'tailwind.config.js',
        language: 'javascript',
        content: generateTailwindConfig()
      }
    ];
    
    setGeneratedFiles(files);
    setIsGenerating(false);
  };

  const copyToClipboard = async (content: string, index: number) => {
    await navigator.clipboard.writeText(content);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const downloadFile = (file: GeneratedFile) => {
    const blob = new Blob([file.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Input Section */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Code className="w-6 h-6" />
          Code Generator
        </h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Describe what you want to build
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., A dark-mode dashboard card with stats, progress bar, and action buttons..."
              className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              rows={4}
            />
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={generateCode}
              disabled={!prompt.trim() || isGenerating}
              className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Generate Code
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Generated Code */}
      {generatedFiles.length > 0 && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="flex border-b border-gray-200 dark:border-gray-700">
            {generatedFiles.map((file, index) => (
              <button
                key={file.name}
                onClick={() => setActiveFile(index)}
                className={`px-4 py-3 text-sm font-medium flex items-center gap-2 transition-colors ${
                  activeFile === index
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border-b-2 border-blue-600'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                <FileCode className="w-4 h-4" />
                {file.name}
              </button>
            ))}
          </div>
          
          <div className="relative">
            <div className="absolute top-4 right-4 flex gap-2">
              <button
                onClick={() => copyToClipboard(generatedFiles[activeFile].content, activeFile)}
                className="p-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
                title="Copy to clipboard"
              >
                {copiedIndex === activeFile ? (
                  <Check className="w-4 h-4 text-green-600" />
                ) : (
                  <Copy className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                )}
              </button>
              
              <button
                onClick={() => downloadFile(generatedFiles[activeFile])}
                className="p-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
                title="Download file"
              >
                <Download className="w-4 h-4 text-gray-600 dark:text-gray-400" />
              </button>
            </div>
            
            <pre className="p-4 pt-16 bg-gray-900 text-gray-100 overflow-x-auto text-sm font-mono">
              {generatedFiles[activeFile].content}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};

// Loader component for generating state
const Loader2 = ({ className }: { className?: string }) => (
  <svg 
    className={className} 
    xmlns="http://www.w3.org/2000/svg" 
    width="24" 
    height="24" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
  </svg>
);
