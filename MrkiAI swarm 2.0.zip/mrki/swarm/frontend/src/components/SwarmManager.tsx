import React, { useState } from 'react';
import { 
  Users, 
  Play, 
  Pause, 
  RotateCcw, 
  Brain, 
  Search, 
  FileText,
  Share2
} from 'lucide-react';
import { Agent, SwarmTask } from '../types';

// Swarm Manager with 3 specialized agents:
// - Agent A (Researcher): Fetches and parses real-time data
// - Agent B (Analyst): Processes data and performs sentiment analysis
// - Agent C (Writer): Generates formatted executive summary

const DEFAULT_AGENTS: Agent[] = [
  {
    id: 'researcher',
    name: 'Researcher',
    role: 'Agent A',
    description: 'Fetches and parses real-time market data via API',
    icon: Search,
    status: 'idle',
    color: 'blue',
    capabilities: ['API fetching', 'Data parsing', 'Web scraping']
  },
  {
    id: 'analyst',
    name: 'Analyst',
    role: 'Agent B',
    description: 'Processes data and performs sentiment analysis',
    icon: Brain,
    status: 'idle',
    color: 'purple',
    capabilities: ['Data processing', 'Sentiment analysis', 'Pattern recognition']
  },
  {
    id: 'writer',
    name: 'Writer',
    role: 'Agent C',
    description: 'Generates formatted executive summary for the user',
    icon: FileText,
    status: 'idle',
    color: 'green',
    capabilities: ['Report generation', 'Summarization', 'Formatting']
  }
];

interface SwarmManagerProps {
  onRunSwarm?: (task: SwarmTask) => void;
}

export const SwarmManager: React.FC<SwarmManagerProps> = ({ onRunSwarm }) => {
  const [agents, setAgents] = useState<Agent[]>(DEFAULT_AGENTS);
  const [sharedMemory, setSharedMemory] = useState<Record<string, any>>({});
  const [isRunning, setIsRunning] = useState(false);
  const [taskInput, setTaskInput] = useState('');

  const runSwarm = async () => {
    if (!taskInput.trim() || isRunning) return;
    
    setIsRunning(true);
    
    // Initialize shared memory
    const context = {
      task: taskInput,
      data: null,
      analysis: null,
      summary: null,
      timestamp: Date.now()
    };
    
    setSharedMemory(context);
    
    // Step 1: Researcher fetches data
    setAgents(prev => prev.map(a => 
      a.id === 'researcher' ? { ...a, status: 'working' } : a
    ));
    
    await simulateAgentWork('researcher', 2000);
    
    context.data = {
      marketData: 'Simulated market data...',
      sources: ['API 1', 'API 2'],
      rawContent: 'Raw fetched content...'
    };
    
    setSharedMemory({ ...context });
    setAgents(prev => prev.map(a => 
      a.id === 'researcher' ? { ...a, status: 'completed' } : 
      a.id === 'analyst' ? { ...a, status: 'working' } : a
    ));
    
    // Step 2: Analyst processes data
    await simulateAgentWork('analyst', 2000);
    
    context.analysis = {
      sentiment: 'Positive',
      confidence: 0.85,
      keyInsights: ['Insight 1', 'Insight 2'],
      trends: ['Trend 1', 'Trend 2']
    };
    
    setSharedMemory({ ...context });
    setAgents(prev => prev.map(a => 
      a.id === 'analyst' ? { ...a, status: 'completed' } : 
      a.id === 'writer' ? { ...a, status: 'working' } : a
    ));
    
    // Step 3: Writer generates summary
    await simulateAgentWork('writer', 2000);
    
    context.summary = {
      executiveSummary: 'Generated executive summary...',
      recommendations: ['Recommendation 1', 'Recommendation 2'],
      conclusion: 'Final conclusion...'
    };
    
    setSharedMemory({ ...context });
    setAgents(prev => prev.map(a => 
      a.id === 'writer' ? { ...a, status: 'completed' } : a
    ));
    
    setIsRunning(false);
    
    if (onRunSwarm) {
      onRunSwarm({
        id: Date.now().toString(),
        type: 'SWARM_ORCHESTRATION',
        input: taskInput,
        output: context,
        agents: agents.map(a => a.id),
        timestamp: Date.now()
      });
    }
  };

  const simulateAgentWork = (agentId: string, duration: number) => {
    return new Promise(resolve => setTimeout(resolve, duration));
  };

  const resetSwarm = () => {
    setAgents(DEFAULT_AGENTS);
    setSharedMemory({});
    setIsRunning(false);
    setTaskInput('');
  };

  const getStatusColor = (status: Agent['status']) => {
    switch (status) {
      case 'idle':
        return 'text-gray-500 dark:text-gray-400';
      case 'working':
        return 'text-blue-500 animate-pulse';
      case 'completed':
        return 'text-green-500';
      case 'error':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Swarm Configuration */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Users className="w-6 h-6" />
          Swarm Configuration
        </h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Task Description
            </label>
            <textarea
              value={taskInput}
              onChange={(e) => setTaskInput(e.target.value)}
              placeholder="Describe what you want the swarm to accomplish..."
              className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              rows={3}
              disabled={isRunning}
            />
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={runSwarm}
              disabled={!taskInput.trim() || isRunning}
              className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
            >
              {isRunning ? (
                <>
                  <RotateCcw className="w-4 h-4 animate-spin" />
                  Running...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Run Swarm
                </>
              )}
            </button>
            
            <button
              onClick={resetSwarm}
              disabled={isRunning}
              className="px-4 py-2 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </button>
          </div>
        </div>
      </div>

      {/* Agent Cards */}
      <div className="grid grid-cols-3 gap-4">
        {agents.map((agent) => {
          const Icon = agent.icon;
          return (
            <div 
              key={agent.id}
              className={`bg-white dark:bg-gray-800 rounded-xl shadow-sm border-2 transition-all ${
                agent.status === 'working' 
                  ? 'border-blue-500 ring-2 ring-blue-500/20' 
                  : 'border-gray-200 dark:border-gray-700'
              }`}
            >
              <div className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-2 rounded-lg bg-${agent.color}-100 dark:bg-${agent.color}-900/30`}>
                    <Icon className={`w-5 h-5 text-${agent.color}-600 dark:text-${agent.color}-400`} />
                  </div>
                  <span className={`text-xs font-medium uppercase ${getStatusColor(agent.status)}`}>
                    {agent.status}
                  </span>
                </div>
                
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                  {agent.name}
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
                  {agent.role}
                </p>
                
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                  {agent.description}
                </p>
                
                <div className="flex flex-wrap gap-1">
                  {agent.capabilities.map((cap, idx) => (
                    <span 
                      key={idx}
                      className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded"
                    >
                      {cap}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Shared Memory State */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Share2 className="w-5 h-5" />
          Shared Memory State
        </h3>
        
        {Object.keys(sharedMemory).length === 0 ? (
          <div className="text-center text-gray-500 dark:text-gray-400 py-8">
            No shared memory yet. Run the swarm to see context passing between agents.
          </div>
        ) : (
          <div className="space-y-3">
            {Object.entries(sharedMemory).map(([key, value]) => (
              <div 
                key={key}
                className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg"
              >
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                  {key}
                </span>
                <pre className="mt-1 text-sm text-gray-700 dark:text-gray-300 font-mono overflow-x-auto">
                  {JSON.stringify(value, null, 2)}
                </pre>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
