import { useState, useCallback } from 'react';
import { ReasoningStep } from '../types';

// ReAct (Reasoning + Acting) Pattern
// The swarm shows its thought process through:
// 1. THOUGHT - Internal reasoning
// 2. ACTION - What it decides to do
// 3. OBSERVATION - What it observes from the action

export const useReAct = () => {
  const [reasoningChain, setReasoningChain] = useState<ReasoningStep[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [isReasoning, setIsReasoning] = useState(false);

  const addThought = useCallback((content: string, agentName?: string) => {
    const step: ReasoningStep = {
      id: Date.now().toString(),
      type: 'THOUGHT',
      content,
      agentName,
      timestamp: Date.now()
    };
    
    setReasoningChain(prev => [...prev, step]);
    setCurrentStep(prev => prev + 1);
  }, []);

  const addAction = useCallback((content: string, action: string, agentName?: string) => {
    const step: ReasoningStep = {
      id: Date.now().toString(),
      type: 'ACTION',
      content,
      action,
      agentName,
      timestamp: Date.now()
    };
    
    setReasoningChain(prev => [...prev, step]);
    setCurrentStep(prev => prev + 1);
  }, []);

  const addObservation = useCallback((content: string, observation: string, agentName?: string) => {
    const step: ReasoningStep = {
      id: Date.now().toString(),
      type: 'OBSERVATION',
      content,
      observation,
      agentName,
      timestamp: Date.now()
    };
    
    setReasoningChain(prev => [...prev, step]);
    setCurrentStep(prev => prev + 1);
  }, []);

  const startReasoning = useCallback(() => {
    setIsReasoning(true);
    setReasoningChain([]);
    setCurrentStep(0);
  }, []);

  const stopReasoning = useCallback(() => {
    setIsReasoning(false);
  }, []);

  const clearReasoning = useCallback(() => {
    setReasoningChain([]);
    setCurrentStep(0);
    setIsReasoning(false);
  }, []);

  // Simulate a complete ReAct cycle
  const simulateReActCycle = useCallback(async (task: string) => {
    startReasoning();
    
    // Thought 1: Understanding the task
    addThought(
      `I need to understand what the user wants: "${task}"`,
      'Swarm Manager'
    );
    
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Action 1: Break down the task
    addAction(
      'Breaking down the task into sub-tasks',
      'DECOMPOSE_TASK',
      'Swarm Manager'
    );
    
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Observation 1: Task decomposed
    addObservation(
      'Task has been decomposed into 3 sub-tasks',
      'Found 3 sub-tasks: research, analysis, writing',
      'Swarm Manager'
    );
    
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Thought 2: Planning approach
    addThought(
      'I should dispatch these tasks to specialized agents in parallel',
      'Swarm Manager'
    );
    
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Action 2: Dispatch to agents
    addAction(
      'Dispatching tasks to Researcher, Analyst, and Writer agents',
      'DISPATCH_TO_AGENTS',
      'Swarm Manager'
    );
    
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Observation 2: Agents working
    addObservation(
      'All agents are now working on their tasks',
      'Researcher: fetching data, Analyst: processing, Writer: preparing',
      'Swarm Manager'
    );
    
    stopReasoning();
  }, [addThought, addAction, addObservation, startReasoning, stopReasoning]);

  return {
    reasoningChain,
    currentStep,
    isReasoning,
    addThought,
    addAction,
    addObservation,
    startReasoning,
    stopReasoning,
    clearReasoning,
    simulateReActCycle
  };
};
