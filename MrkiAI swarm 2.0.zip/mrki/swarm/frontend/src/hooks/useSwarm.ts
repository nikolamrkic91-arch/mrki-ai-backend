import { useState, useCallback } from 'react';
import { Agent, Task, Activity } from '../types';

// Simulated initial agents
const INITIAL_AGENTS: Agent[] = [
  {
    id: 'architect',
    name: 'Architect',
    role: 'System Designer',
    description: 'Creates blueprints and system architecture',
    icon: () => null,
    status: 'idle',
    color: 'blue',
    capabilities: ['System design', 'Schema creation', 'API design']
  },
  {
    id: 'coder',
    name: 'Coder',
    role: 'Implementation',
    description: 'Writes React/Tailwind code',
    icon: () => null,
    status: 'idle',
    color: 'green',
    capabilities: ['Code generation', 'File system', 'Git integration']
  },
  {
    id: 'reviewer',
    name: 'Reviewer',
    role: 'Quality Assurance',
    description: 'Reviews code for bugs and security',
    icon: () => null,
    status: 'idle',
    color: 'purple',
    capabilities: ['Static analysis', 'Test execution', 'Security audit']
  }
];

export const useSwarm = () => {
  const [agents, setAgents] = useState<Agent[]>(INITIAL_AGENTS);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [swarmActivity, setSwarmActivity] = useState<Activity[]>([]);

  const dispatchTask = useCallback((task: any) => {
    const newTask: Task = {
      id: Date.now().toString(),
      type: task.type,
      status: 'pending',
      input: task.payload,
      timestamp: Date.now()
    };
    
    setTasks(prev => [...prev, newTask]);
    
    // Add activity
    const activity: Activity = {
      id: Date.now().toString(),
      type: 'ACTION',
      agentName: 'Swarm Manager',
      message: `Dispatched task: ${task.type}`,
      timestamp: Date.now(),
      metadata: task.payload
    };
    
    setSwarmActivity(prev => [...prev, activity]);
    
    // Simulate task processing
    setTimeout(() => {
      setTasks(prev => 
        prev.map(t => 
          t.id === newTask.id ? { ...t, status: 'completed' } : t
        )
      );
      
      const completionActivity: Activity = {
        id: Date.now().toString(),
        type: 'COMPLETED',
        agentName: 'Swarm Manager',
        message: `Task completed: ${task.type}`,
        timestamp: Date.now()
      };
      
      setSwarmActivity(prev => [...prev, completionActivity]);
    }, 2000);
  }, []);

  const toggleAgent = useCallback((agentId: string) => {
    setAgents(prev => 
      prev.map(agent => 
        agent.id === agentId 
          ? { ...agent, status: agent.status === 'idle' ? 'working' : 'idle' }
          : agent
      )
    );
  }, []);

  const getAgentStatus = useCallback((agentId: string) => {
    const agent = agents.find(a => a.id === agentId);
    return agent?.status || 'idle';
  }, [agents]);

  const addActivity = useCallback((activity: Activity) => {
    setSwarmActivity(prev => [...prev, activity]);
  }, []);

  return {
    agents,
    tasks,
    swarmActivity,
    dispatchTask,
    toggleAgent,
    getAgentStatus,
    addActivity
  };
};
