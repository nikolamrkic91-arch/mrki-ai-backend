import { LucideIcon } from 'lucide-react';

// Agent Types
export interface Agent {
  id: string;
  name: string;
  role: string;
  description: string;
  icon: LucideIcon;
  status: 'idle' | 'working' | 'completed' | 'error';
  color: string;
  capabilities: string[];
}

// Task Types
export interface Task {
  id: string;
  type: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  input: any;
  output?: any;
  timestamp: number;
  completedAt?: number;
}

// Activity Types
export interface Activity {
  id: string;
  type: 'THOUGHT' | 'ACTION' | 'OBSERVATION' | 'CODE_GENERATION' | 'COMPLETED' | 'ERROR';
  agentName: string;
  message: string;
  timestamp: number;
  metadata?: any;
}

// ReAct Reasoning Types
export interface ReasoningStep {
  id: string;
  type: 'THOUGHT' | 'ACTION' | 'OBSERVATION';
  content: string;
  action?: string;
  observation?: string;
  agentName?: string;
  timestamp: number;
}

// Swarm Task Types
export interface SwarmTask {
  id: string;
  type: string;
  input: string;
  output?: any;
  agents: string[];
  timestamp: number;
}

// Code Generation Types
export interface CodeFile {
  name: string;
  language: string;
  content: string;
}

export interface GeneratedCode {
  files: CodeFile[];
  prompt: string;
  timestamp: number;
}

// WebSocket Types
export interface WebSocketMessage {
  type: string;
  payload: any;
  timestamp: number;
}

// Component Props Types
export interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: 'dashboard' | 'agents' | 'code' | 'settings') => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  isConnected: boolean;
}
