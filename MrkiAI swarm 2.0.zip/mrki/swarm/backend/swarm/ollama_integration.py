"""
Ollama Integration - Local LLM Processing
Allows switching to local Ollama instance for data-sensitive tasks
"""

import requests
from typing import Dict, Any, Optional, List, AsyncGenerator
import json
import os

class OllamaClient:
    """
    Client for interacting with local Ollama instance
    Provides privacy-focused local LLM processing
    """
    
    def __init__(self, host: Optional[str] = None):
        self.host = host or os.getenv("OLLAMA_HOST", "http://localhost:11434")
        self.session = requests.Session()
    
    def is_available(self) -> bool:
        """Check if Ollama is available"""
        try:
            response = self.session.get(f"{self.host}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def list_models(self) -> List[str]:
        """List available models"""
        try:
            response = self.session.get(f"{self.host}/api/tags")
            if response.status_code == 200:
                data = response.json()
                return [model["name"] for model in data.get("models", [])]
            return []
        except Exception as e:
            print(f"Error listing models: {e}")
            return []
    
    def generate(
        self, 
        model: str, 
        prompt: str, 
        system: Optional[str] = None,
        options: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate text using Ollama"""
        url = f"{self.host}/api/generate"
        
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False
        }
        
        if system:
            payload["system"] = system
        
        if options:
            payload["options"] = options
        
        try:
            response = self.session.post(url, json=payload)
            response.raise_for_status()
            data = response.json()
            return data.get("response", "")
        except Exception as e:
            print(f"Error generating with Ollama: {e}")
            raise
    
    async def generate_stream(
        self, 
        model: str, 
        prompt: str,
        system: Optional[str] = None,
        options: Optional[Dict[str, Any]] = None
    ) -> AsyncGenerator[str, None]:
        """Stream generate text using Ollama"""
        url = f"{self.host}/api/generate"
        
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": True
        }
        
        if system:
            payload["system"] = system
        
        if options:
            payload["options"] = options
        
        try:
            response = self.session.post(url, json=payload, stream=True)
            response.raise_for_status()
            
            for line in response.iter_lines():
                if line:
                    data = json.loads(line)
                    if "response" in data:
                        yield data["response"]
        except Exception as e:
            print(f"Error streaming from Ollama: {e}")
            raise
    
    def chat(
        self, 
        model: str, 
        messages: List[Dict[str, str]],
        options: Optional[Dict[str, Any]] = None
    ) -> str:
        """Chat with Ollama"""
        url = f"{self.host}/api/chat"
        
        payload = {
            "model": model,
            "messages": messages,
            "stream": False
        }
        
        if options:
            payload["options"] = options
        
        try:
            response = self.session.post(url, json=payload)
            response.raise_for_status()
            data = response.json()
            return data.get("message", {}).get("content", "")
        except Exception as e:
            print(f"Error chatting with Ollama: {e}")
            raise
    
    def pull_model(self, model: str) -> bool:
        """Pull a model from Ollama registry"""
        url = f"{self.host}/api/pull"
        
        payload = {
            "name": model,
            "stream": False
        }
        
        try:
            response = self.session.post(url, json=payload)
            return response.status_code == 200
        except Exception as e:
            print(f"Error pulling model: {e}")
            return False
    
    def delete_model(self, model: str) -> bool:
        """Delete a model from Ollama"""
        url = f"{self.host}/api/delete"
        
        try:
            response = self.session.delete(url, json={"name": model})
            return response.status_code == 200
        except Exception as e:
            print(f"Error deleting model: {e}")
            return False

class OllamaProvider:
    """
    LLM Provider that uses Ollama for local processing
    Can be used as a drop-in replacement for OpenAI/Anthropic
    """
    
    def __init__(self, default_model: str = "llama3.2"):
        self.client = OllamaClient()
        self.default_model = default_model
    
    async def complete(
        self, 
        prompt: str, 
        model: Optional[str] = None,
        system: Optional[str] = None,
        **kwargs
    ) -> str:
        """Complete a prompt using Ollama"""
        if not self.client.is_available():
            raise RuntimeError("Ollama is not available")
        
        model = model or self.default_model
        
        return self.client.generate(
            model=model,
            prompt=prompt,
            system=system,
            options=kwargs
        )
    
    async def chat_complete(
        self, 
        messages: List[Dict[str, str]], 
        model: Optional[str] = None,
        **kwargs
    ) -> str:
        """Complete a chat using Ollama"""
        if not self.client.is_available():
            raise RuntimeError("Ollama is not available")
        
        model = model or self.default_model
        
        return self.client.chat(
            model=model,
            messages=messages,
            options=kwargs
        )
    
    async def stream_complete(
        self, 
        prompt: str, 
        model: Optional[str] = None,
        system: Optional[str] = None,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """Stream complete a prompt using Ollama"""
        if not self.client.is_available():
            raise RuntimeError("Ollama is not available")
        
        model = model or self.default_model
        
        async for chunk in self.client.generate_stream(
            model=model,
            prompt=prompt,
            system=system,
            options=kwargs
        ):
            yield chunk

# Factory function to get LLM provider
def get_llm_provider(provider_type: str = "openai", **kwargs):
    """
    Get an LLM provider instance
    
    Args:
        provider_type: "openai", "anthropic", or "ollama"
        **kwargs: Provider-specific arguments
    
    Returns:
        LLM provider instance
    """
    if provider_type == "ollama":
        return OllamaProvider(
            default_model=kwargs.get("model", "llama3.2")
        )
    elif provider_type == "openai":
        from swarm.openai_provider import OpenAIProvider
        return OpenAIProvider(**kwargs)
    elif provider_type == "anthropic":
        from swarm.anthropic_provider import AnthropicProvider
        return AnthropicProvider(**kwargs)
    else:
        raise ValueError(f"Unknown provider type: {provider_type}")
