"""
Code Generator - Generates React/Tailwind code from prompts
"""

from typing import Dict, Any, List
import json

class CodeGenerator:
    """Generates code from natural language prompts"""
    
    def __init__(self):
        self.templates = {
            "react": self._get_react_template(),
            "vue": self._get_vue_template(),
            "angular": self._get_angular_template()
        }
    
    async def generate(
        self, 
        prompt: str, 
        language: str = "typescript",
        framework: str = "react"
    ) -> Dict[str, Any]:
        """Generate code from prompt"""
        
        # Generate component name from prompt
        component_name = self._generate_component_name(prompt)
        
        # Generate files based on framework
        if framework == "react":
            files = self._generate_react(component_name, prompt, language)
        elif framework == "vue":
            files = self._generate_vue(component_name, prompt)
        elif framework == "angular":
            files = self._generate_angular(component_name, prompt)
        else:
            files = self._generate_react(component_name, prompt, language)
        
        return {
            "component_name": component_name,
            "framework": framework,
            "language": language,
            "files": files,
            "prompt": prompt
        }
    
    def _generate_component_name(self, prompt: str) -> str:
        """Generate a component name from the prompt"""
        words = prompt.split()[:4]
        name = "".join(word.capitalize() for word in words)
        name = "".join(c for c in name if c.isalnum())
        return name or "GeneratedComponent"
    
    def _generate_react(
        self, 
        component_name: str, 
        prompt: str,
        language: str
    ) -> List[Dict[str, str]]:
        """Generate React component files"""
        
        ext = "tsx" if language == "typescript" else "jsx"
        
        component_code = f"""import React from 'react';
import {{ Card, CardHeader, CardTitle, CardContent }} from '@/components/ui/card';
import {{ Button }} from '@/components/ui/button';

interface {component_name}Props {{
  title?: string;
  description?: string;
  onAction?: () => void;
}}

export const {component_name}: React.FC<{component_name}Props> = ({{
  title = 'Generated Component',
  description = 'Component generated from: {prompt}',
  onAction
}}) => {{
  return (
    <Card className="w-full max-w-md bg-white dark:bg-gray-800 shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-900 dark:text-white">
          {{title}}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-gray-600 dark:text-gray-300">
          {{description}}
        </p>
        <div className="flex gap-2">
          <Button onClick={{onAction}} className="flex-1">
            Action
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}};

export default {component_name};
"""
        
        styles_code = f"""/* Tailwind CSS classes for {component_name} */
/* Generated from: {prompt} */

.{component_name.lower()} {{
  @apply bg-white dark:bg-gray-800 rounded-lg shadow-md p-6;
}}
"""
        
        return [
            {
                "name": f"{component_name}.{ext}",
                "language": language,
                "content": component_code
            },
            {
                "name": f"{component_name}.module.css",
                "language": "css",
                "content": styles_code
            }
        ]
    
    def _generate_vue(self, component_name: str, prompt: str) -> List[Dict[str, str]]:
        """Generate Vue component files"""
        
        template = f"""<template>
  <div class="{component_name.lower()}">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <h2 class="text-xl font-bold text-gray-900 dark:text-white">{{ title }}</h2>
      <p class="text-gray-600 dark:text-gray-300 mt-2">{{ description }}</p>
      <button 
        @click="handleAction"
        class="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
      >
        Action
      </button>
    </div>
  </div>
</template>

<script setup>
import {{ ref }} from 'vue';

const props = defineProps({{
  title: {{ type: String, default: 'Generated Component' }},
  description: {{ type: String, default: 'Component generated from: {prompt}' }}
}});

const emit = defineEmits(['action']);

const handleAction = () => {{
  emit('action');
}};
</script>

<style scoped>
.{component_name.lower()} {{
  @apply w-full max-w-md;
}}
</style>
"""
        
        return [
            {
                "name": f"{component_name}.vue",
                "language": "vue",
                "content": template
            }
        ]
    
    def _generate_angular(self, component_name: str, prompt: str) -> List[Dict[str, str]]:
        """Generate Angular component files"""
        
        ts_code = f"""import {{ Component, Input, Output, EventEmitter }} from '@angular/core';

@Component({{
  selector: 'app-{component_name.lower()}',
  templateUrl: './{component_name.lower()}.component.html',
  styleUrls: ['./{component_name.lower()}.component.css']
}})
export class {component_name}Component {{
  @Input() title = 'Generated Component';
  @Input() description = 'Component generated from: {prompt}';
  @Output() action = new EventEmitter<void>();

  handleAction() {{
    this.action.emit();
  }}
}}
"""
        
        html_code = f"""<div class="{component_name.lower()}">
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
    <h2 class="text-xl font-bold text-gray-900 dark:text-white">{{ title }}</h2>
    <p class="text-gray-600 dark:text-gray-300 mt-2">{{ description }}</p>
    <button 
      (click)="handleAction()"
      class="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
    >
      Action
    </button>
  </div>
</div>
"""
        
        css_code = f"""/* {component_name} component styles */
/* Generated from: {prompt} */

.{component_name.lower()} {{
  display: block;
  width: 100%;
  max-width: 28rem;
}}
"""
        
        return [
            {
                "name": f"{component_name.lower()}.component.ts",
                "language": "typescript",
                "content": ts_code
            },
            {
                "name": f"{component_name.lower()}.component.html",
                "language": "html",
                "content": html_code
            },
            {
                "name": f"{component_name.lower()}.component.css",
                "language": "css",
                "content": css_code
            }
        ]
    
    def _get_react_template(self) -> str:
        return "react"
    
    def _get_vue_template(self) -> str:
        return "vue"
    
    def _get_angular_template(self) -> str:
        return "angular"
