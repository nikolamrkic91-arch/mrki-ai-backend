"""
Swarm Orchestrator - Manages the 3 specialized agents
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import asyncio

class SwarmOrchestrator:
    """Orchestrates the multi-agent swarm with shared memory"""
    
    def __init__(self):
        self.agents: Dict[str, Any] = {}
        self.tasks: List[Dict] = []
        self.status = "idle"
        self.shared_memory: Dict[str, Any] = {}
    
    def register_agent(self, agent_id: str, agent: Any):
        """Register an agent with the orchestrator"""
        self.agents[agent_id] = {
            "instance": agent,
            "status": "idle",
            "last_activity": None
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Get current orchestrator status"""
        return {
            "status": self.status,
            "registered_agents": list(self.agents.keys()),
            "agent_states": {
                agent_id: {
                    "status": info["status"],
                    "last_activity": info["last_activity"]
                }
                for agent_id, info in self.agents.items()
            },
            "task_count": len(self.tasks),
            "timestamp": datetime.now().isoformat()
        }
    
    async def execute_parallel(self, tasks: List[Dict[str, Any]]) -> List[Any]:
        """Execute multiple agent tasks in parallel"""
        async def run_task(task_def: Dict[str, Any]):
            agent_id = task_def.get("agent_id")
            task_data = task_def.get("task")
            
            if agent_id not in self.agents:
                raise ValueError(f"Agent {agent_id} not registered")
            
            agent_info = self.agents[agent_id]
            agent_info["status"] = "working"
            agent_info["last_activity"] = datetime.now().isoformat()
            
            try:
                agent = agent_info["instance"]
                result = await agent.execute(task_data)
                agent_info["status"] = "idle"
                return {"agent_id": agent_id, "result": result, "success": True}
            except Exception as e:
                agent_info["status"] = "error"
                return {"agent_id": agent_id, "error": str(e), "success": False}
        
        # Run all tasks in parallel
        results = await asyncio.gather(*[run_task(task) for task in tasks])
        return results
    
    async def execute_sequential(self, tasks: List[Dict[str, Any]]) -> List[Any]:
        """Execute tasks sequentially, passing context between them"""
        results = []
        context = {}
        
        for task_def in tasks:
            agent_id = task_def.get("agent_id")
            task_data = task_def.get("task")
            
            # Merge context into task
            if isinstance(task_data, dict):
                task_data = {**task_data, **context}
            
            result = await self.execute_parallel([{
                "agent_id": agent_id,
                "task": task_data
            }])
            
            # Extract context for next task
            if result[0].get("success"):
                context["previous_result"] = result[0].get("result")
            
            results.extend(result)
        
        return results
    
    def update_shared_memory(self, key: str, value: Any):
        """Update shared memory accessible by all agents"""
        self.shared_memory[key] = value
    
    def get_from_memory(self, key: str) -> Any:
        """Get value from shared memory"""
        return self.shared_memory.get(key)
