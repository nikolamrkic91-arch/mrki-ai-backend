"""
Shared Memory - Context passing between agents
"""

from typing import Dict, Any, Optional, List
from datetime import datetime
import threading

class SharedMemory:
    """
    Shared memory state for seamless context passing between agents.
    All agents can read from and write to this shared state.
    """
    
    def __init__(self):
        self._memory: Dict[str, Any] = {}
        self._history: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
    
    def set(self, key: str, value: Any) -> None:
        """Store a value in shared memory"""
        with self._lock:
            self._memory[key] = value
            self._history.append({
                "operation": "SET",
                "key": key,
                "timestamp": datetime.now().isoformat()
            })
    
    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve a value from shared memory"""
        with self._lock:
            return self._memory.get(key, default)
    
    def get_all(self) -> Dict[str, Any]:
        """Get all memory contents"""
        with self._lock:
            return self._memory.copy()
    
    def delete(self, key: str) -> bool:
        """Delete a key from shared memory"""
        with self._lock:
            if key in self._memory:
                del self._memory[key]
                self._history.append({
                    "operation": "DELETE",
                    "key": key,
                    "timestamp": datetime.now().isoformat()
                })
                return True
            return False
    
    def clear(self) -> None:
        """Clear all memory"""
        with self._lock:
            self._memory.clear()
            self._history.append({
                "operation": "CLEAR",
                "timestamp": datetime.now().isoformat()
            })
    
    def has_key(self, key: str) -> bool:
        """Check if a key exists in memory"""
        with self._lock:
            return key in self._memory
    
    def keys(self) -> List[str]:
        """Get all keys in memory"""
        with self._lock:
            return list(self._memory.keys())
    
    def get_history(self) -> List[Dict[str, Any]]:
        """Get operation history"""
        with self._lock:
            return self._history.copy()
    
    def merge(self, data: Dict[str, Any]) -> None:
        """Merge a dictionary into shared memory"""
        with self._lock:
            self._memory.update(data)
            self._history.append({
                "operation": "MERGE",
                "keys": list(data.keys()),
                "timestamp": datetime.now().isoformat()
            })
