"""
ReAct (Reasoning + Acting) Engine
Implements the ReAct pattern for transparent AI reasoning
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import asyncio

class ReActEngine:
    """
    ReAct Pattern Implementation
    
    The ReAct pattern consists of three steps:
    1. THOUGHT - Internal reasoning about the task
    2. ACTION - What the agent decides to do
    3. OBSERVATION - What the agent observes from the action
    
    This creates a transparent reasoning chain that can be displayed in the UI.
    """
    
    def __init__(self):
        self.reasoning_chain: List[Dict[str, Any]] = []
        self.current_step = 0
        self.is_thinking = False
    
    async def start_thinking(self, task: str) -> None:
        """Start a new ReAct reasoning cycle"""
        self.is_thinking = True
        self.current_step = 0
        self.reasoning_chain = []
        
        # Initial thought about the task
        await self.add_thought(
            f"I need to understand and solve this task: {task}",
            "Swarm Manager"
        )
    
    async def add_thought(self, content: str, agent_name: str = "System") -> None:
        """Add a THOUGHT step to the reasoning chain"""
        step = {
            "id": f"step_{self.current_step}",
            "type": "THOUGHT",
            "content": content,
            "agent_name": agent_name,
            "timestamp": datetime.now().isoformat()
        }
        self.reasoning_chain.append(step)
        self.current_step += 1
        
        # Simulate thinking time
        await asyncio.sleep(0.5)
    
    async def add_action(self, content: str, action_data: Any, agent_name: str = "System") -> None:
        """Add an ACTION step to the reasoning chain"""
        step = {
            "id": f"step_{self.current_step}",
            "type": "ACTION",
            "content": content,
            "action": action_data if isinstance(action_data, str) else str(action_data),
            "agent_name": agent_name,
            "timestamp": datetime.now().isoformat()
        }
        self.reasoning_chain.append(step)
        self.current_step += 1
        
        # Simulate action time
        await asyncio.sleep(0.5)
    
    async def add_observation(self, content: str, observation_data: Any, agent_name: str = "System") -> None:
        """Add an OBSERVATION step to the reasoning chain"""
        step = {
            "id": f"step_{self.current_step}",
            "type": "OBSERVATION",
            "content": content,
            "observation": observation_data if isinstance(observation_data, str) else str(observation_data),
            "agent_name": agent_name,
            "timestamp": datetime.now().isoformat()
        }
        self.reasoning_chain.append(step)
        self.current_step += 1
        
        # Simulate observation time
        await asyncio.sleep(0.5)
    
    async def complete(self) -> None:
        """Complete the reasoning cycle"""
        await self.add_thought(
            "Task completed successfully. All steps executed.",
            "Swarm Manager"
        )
        self.is_thinking = False
    
    def get_chain(self) -> List[Dict[str, Any]]:
        """Get the full reasoning chain"""
        return self.reasoning_chain.copy()
    
    def get_current_step(self) -> int:
        """Get current step number"""
        return self.current_step
    
    def is_active(self) -> bool:
        """Check if reasoning is in progress"""
        return self.is_thinking
    
    def clear(self) -> None:
        """Clear the reasoning chain"""
        self.reasoning_chain = []
        self.current_step = 0
        self.is_thinking = False
