"""
Mrki Swarm Backend
FastAPI + Node.js Hybrid Backend for AI Swarm Orchestration
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncio
import json
from datetime import datetime

# Import swarm modules
from swarm.orchestrator import SwarmOrchestrator
from swarm.agents import ResearcherAgent, AnalystAgent, WriterAgent
from swarm.memory import SharedMemory
from swarm.react import ReActEngine

app = FastAPI(
    title="Mrki Swarm API",
    description="AI Swarm Orchestration Platform Backend",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global state
orchestrator = SwarmOrchestrator()
shared_memory = SharedMemory()
react_engine = ReActEngine()

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                pass

manager = ConnectionManager()

# Pydantic models
class TaskRequest(BaseModel):
    task: str
    context: Optional[Dict[str, Any]] = {}

class CodeRequest(BaseModel):
    prompt: str
    language: str = "typescript"
    framework: str = "react"

class SwarmResponse(BaseModel):
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

# Health check
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0",
        "services": {
            "orchestrator": "running",
            "memory": "active",
            "react_engine": "ready"
        }
    }

# Run swarm task
@app.post("/swarm/run", response_model=SwarmResponse)
async def run_swarm(request: TaskRequest):
    """
    Run a swarm task with the 3 specialized agents:
    - Researcher: Fetches and parses data
    - Analyst: Processes and analyzes
    - Writer: Generates summary
    """
    try:
        # Initialize shared memory
        shared_memory.clear()
        shared_memory.set("task", request.task)
        shared_memory.set("context", request.context)
        
        # Start ReAct reasoning
        await react_engine.start_thinking(request.task)
        
        # Step 1: Researcher fetches data
        researcher = ResearcherAgent()
        research_result = await researcher.execute(request.task)
        shared_memory.set("research", research_result)
        
        await react_engine.add_action("Researcher fetched data", research_result)
        
        # Step 2: Analyst processes data
        analyst = AnalystAgent()
        analysis_result = await analyst.execute(research_result)
        shared_memory.set("analysis", analysis_result)
        
        await react_engine.add_action("Analyst processed data", analysis_result)
        
        # Step 3: Writer generates summary
        writer = WriterAgent()
        summary = await writer.execute(analysis_result)
        shared_memory.set("summary", summary)
        
        await react_engine.add_observation("Writer generated summary", summary)
        
        # Complete reasoning
        await react_engine.complete()
        
        # Broadcast to all connected clients
        await manager.broadcast({
            "type": "SWARM_COMPLETED",
            "payload": {
                "task": request.task,
                "research": research_result,
                "analysis": analysis_result,
                "summary": summary,
                "reasoning_chain": react_engine.get_chain()
            },
            "timestamp": datetime.now().isoformat()
        })
        
        return SwarmResponse(
            success=True,
            data={
                "task": request.task,
                "research": research_result,
                "analysis": analysis_result,
                "summary": summary,
                "shared_memory": shared_memory.get_all()
            }
        )
    
    except Exception as e:
        return SwarmResponse(
            success=False,
            error=str(e)
        )

# Generate code
@app.post("/code/generate")
async def generate_code(request: CodeRequest):
    """Generate React/Tailwind code from prompt"""
    try:
        from swarm.code_generator import CodeGenerator
        
        generator = CodeGenerator()
        result = await generator.generate(
            prompt=request.prompt,
            language=request.language,
            framework=request.framework
        )
        
        return {
            "success": True,
            "data": result
        }
    
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

# Get swarm status
@app.get("/swarm/status")
async def get_swarm_status():
    """Get current swarm status and agent states"""
    return {
        "orchestrator": orchestrator.get_status(),
        "memory": shared_memory.get_all(),
        "reasoning_chain": react_engine.get_chain(),
        "agents": [
            {"id": "researcher", "name": "Researcher", "status": "idle"},
            {"id": "analyst", "name": "Analyst", "status": "idle"},
            {"id": "writer", "name": "Writer", "status": "idle"}
        ]
    }

# WebSocket endpoint for real-time updates
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    
    try:
        while True:
            # Receive message from client
            data = await websocket.receive_text()
            message = json.loads(data)
            
            # Handle different message types
            if message.get("type") == "PING":
                await websocket.send_json({
                    "type": "PONG",
                    "timestamp": datetime.now().isoformat()
                })
            
            elif message.get("type") == "SUBSCRIBE":
                # Client wants to subscribe to specific events
                await websocket.send_json({
                    "type": "SUBSCRIBED",
                    "events": message.get("events", [])
                })
            
            elif message.get("type") == "RUN_SWARM":
                # Trigger swarm execution
                task = message.get("payload", {}).get("task", "")
                if task:
                    # Run swarm asynchronously
                    asyncio.create_task(run_swarm_task(task, websocket))
    
    except WebSocketDisconnect:
        manager.disconnect(websocket)

async def run_swarm_task(task: str, websocket: WebSocket):
    """Run swarm task and send updates via WebSocket"""
    try:
        # Send initial status
        await websocket.send_json({
            "type": "SWARM_STARTED",
            "payload": {"task": task},
            "timestamp": datetime.now().isoformat()
        })
        
        # Initialize shared memory
        shared_memory.clear()
        shared_memory.set("task", task)
        
        # Step 1: Researcher
        await websocket.send_json({
            "type": "AGENT_STARTED",
            "payload": {"agent": "researcher", "task": "Fetching data"},
            "timestamp": datetime.now().isoformat()
        })
        
        researcher = ResearcherAgent()
        research_result = await researcher.execute(task)
        shared_memory.set("research", research_result)
        
        await websocket.send_json({
            "type": "AGENT_COMPLETED",
            "payload": {"agent": "researcher", "result": research_result},
            "timestamp": datetime.now().isoformat()
        })
        
        # Step 2: Analyst
        await websocket.send_json({
            "type": "AGENT_STARTED",
            "payload": {"agent": "analyst", "task": "Processing data"},
            "timestamp": datetime.now().isoformat()
        })
        
        analyst = AnalystAgent()
        analysis_result = await analyst.execute(research_result)
        shared_memory.set("analysis", analysis_result)
        
        await websocket.send_json({
            "type": "AGENT_COMPLETED",
            "payload": {"agent": "analyst", "result": analysis_result},
            "timestamp": datetime.now().isoformat()
        })
        
        # Step 3: Writer
        await websocket.send_json({
            "type": "AGENT_STARTED",
            "payload": {"agent": "writer", "task": "Generating summary"},
            "timestamp": datetime.now().isoformat()
        })
        
        writer = WriterAgent()
        summary = await writer.execute(analysis_result)
        shared_memory.set("summary", summary)
        
        await websocket.send_json({
            "type": "AGENT_COMPLETED",
            "payload": {"agent": "writer", "result": summary},
            "timestamp": datetime.now().isoformat()
        })
        
        # Complete
        await websocket.send_json({
            "type": "SWARM_COMPLETED",
            "payload": {
                "task": task,
                "research": research_result,
                "analysis": analysis_result,
                "summary": summary
            },
            "timestamp": datetime.now().isoformat()
        })
    
    except Exception as e:
        await websocket.send_json({
            "type": "SWARM_ERROR",
            "payload": {"error": str(e)},
            "timestamp": datetime.now().isoformat()
        })

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
