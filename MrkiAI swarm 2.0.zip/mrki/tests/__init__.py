"""Tests for Mrki."""
