"""Unit tests for Mrki."""
